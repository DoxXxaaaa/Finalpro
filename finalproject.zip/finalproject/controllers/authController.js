const User = require('../models/User');
const bcrypt = require('bcryptjs');
const passport = require('passport');
const nodemailer = require('nodemailer');

exports.register = async (req, res) => {
    try {
        const { username, password, firstName, lastName, age, gender } = req.body;
        const existingUser = await User.findOne({ username });

        if (existingUser) return res.send('User already exists!');

        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = new User({ username, password: hashedPassword, firstName, lastName, age, gender });
        await newUser.save();

        res.redirect('/auth/login');
    } catch (error) {
        console.error(error);
        res.status(500).send('Server error');
    }
};

exports.login = (req, res, next) => {
    passport.authenticate('local', (err, user, info) => {
        if (err || !user) return res.redirect('/auth/login');
        req.logIn(user, (err) => {
            if (err) return next(err);
            res.redirect('/');
        });
    })(req, res, next);
};
