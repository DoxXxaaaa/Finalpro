const Stats = require('../models/Stats');

exports.getStats = async (req, res) => {
    const stats = await Stats.find();
    res.render('stats', { stats });
};

exports.addStat = async (req, res) => {
    const { player, team, goals, assists, matches } = req.body;
    await Stats.create({ player, team, goals, assists, matches });
    res.redirect('/stats');
};
