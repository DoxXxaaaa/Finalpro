const mongoose = require('mongoose');

const statsSchema = new mongoose.Schema({
    player: String,
    team: String,
    goals: Number,
    assists: Number,
    matches: Number
});

module.exports = mongoose.model('Stats', statsSchema);
