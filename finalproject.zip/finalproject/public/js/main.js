console.log("JavaScript Loaded!");
