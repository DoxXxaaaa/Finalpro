const express = require('express');
const adminController = require('../controllers/adminController');
const roleMiddleware = require('../middleware/roleMiddleware');
const router = express.Router();

router.get('/users', roleMiddleware.isAdmin, adminController.getUsers);

module.exports = router;
