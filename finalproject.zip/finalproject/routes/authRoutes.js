const express = require('express');
const authController = require('../controllers/authController');
const router = express.Router();

// Register Route
router.get('/register', (req, res) => res.render('register'));
router.post('/register', authController.register);  // Ensure this function is defined

// Login Route
router.get('/login', (req, res) => res.render('login'));
router.post('/login', authController.login);  // Ensure this function is defined

module.exports = router;
