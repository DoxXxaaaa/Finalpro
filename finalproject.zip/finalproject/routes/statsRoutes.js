const express = require('express');
const statsController = require('../controllers/statsController');
const authMiddleware = require('../middleware/authMiddleware');
const router = express.Router();

router.get('/', authMiddleware.isAuthenticated, statsController.getStats);
router.post('/add', authMiddleware.isAuthenticated, statsController.addStat);

module.exports = router;
