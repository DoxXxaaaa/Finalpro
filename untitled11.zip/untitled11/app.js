const express = require('express');
const expressLayouts = require('express-ejs-layouts');
const mongoose = require('mongoose');
const passport = require('passport');
const flash = require('connect-flash');
const session = require('express-session');
const portfolioRoutes = require('./routes/portfolio');
const axios = require('axios');
const path = require('path');

const app = express();

// Passport Config
require('./config/passport')(passport);

// DB Config
const db = require('./config/keys').mongoURI;

// Connect to MongoDB

// Replace with your MongoDB URI
const mongoURI = 'mongodb+srv://dlcwtptfib:dlcwtptfib@cluster0.iubgh.mongodb.net/todo-app?retryWrites=true&w=majority&appName=Cluster0';

mongoose.connect(mongoURI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
    .then(() => console.log('Connected to MongoDB'))
    .catch((err) => console.error('MongoDB connection error:', err));

//logout

app.get('/logout', (req, res) => {
    req.logout(function(err) {
        if (err) { return next(err); }
        res.redirect('/'); // Redirect to home page or login page
    });
});

// EJS
app.use(expressLayouts);
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Express body parser
app.use(express.urlencoded({ extended: true }));

// Express session
app.use(
    session({
        secret: 'secret',
        resave: true,
        saveUninitialized: true
    })
);

app.use(express.static('public'));

// Passport middleware
app.use(passport.initialize());
app.use(passport.session());

// Connect flash
app.use(flash());

// Global variables
app.use(function(req, res, next) {
    res.locals.success_msg = req.flash('success_msg');
    res.locals.error_msg = req.flash('error_msg');
    res.locals.error = req.flash('error');
    next();
});



// Body parser
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// API Call to fetch sports news data
const getSportsData = async () => {
    try {
        const response = await axios.get('https://www.thesportsdb.com/api/v1/json/1/all_sports.php');
        return response.data.sports;
    } catch (error) {
        console.error("Error fetching sports data", error);
    }
};

// API Call to fetch financial data
const getFinancialData = async () => {
    const API_KEY = 'your_alpha_vantage_api_key';
    try {
        const response = await axios.get(`https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=MSFT&apikey=${API_KEY}`);
        return response.data['Time Series (Daily)'];
    } catch (error) {
        console.error("Error fetching financial data", error);
    }
};

// Home page
app.get('/', (req, res) => {
    res.render('index');
});

// Portfolio page (CRUD for portfolio items)
app.get('/portfolio', async (req, res) => {
    // Fetch portfolio items (this will come from the database in a real app)
    const portfolioItems = [
        {
            title: 'Astana City',
            images: ['astana1.jpg', 'astana2.jpg', 'astana3.jpg'],
            description: 'A beautiful city with modern infrastructure.',
            createdAt: new Date(),
            updatedAt: new Date()
        }
    ];
    res.render('portfolio', { portfolioItems });
});

const SPORTS_API_KEY = '3'; // Replace with your actual API key

app.get('/sports', async (req, res) => {
    const leagueId = '4328'; // Example league ID
    const leagueName = 'English Premier League'; // Example league name
    try {
        // Fetch seasons
        const seasonsResponse = await fetch(`https://www.thesportsdb.com/api/v1/json/${SPORTS_API_KEY}/search_all_seasons.php?id=${leagueId}`);
        const seasonsData = await seasonsResponse.json();
        const seasons = seasonsData.seasons || [];

        // Fetch teams
        const teamsResponse = await fetch(`https://www.thesportsdb.com/api/v1/json/${SPORTS_API_KEY}/search_all_teams.php?l=${encodeURIComponent(leagueName)}`);
        const teamsData = await teamsResponse.json();
        const teams = teamsData.teams || [];

        // Render sports.ejs with both data
        res.render('sports', { seasons, teams });
    } catch (error) {
        console.error('Error fetching sports data:', error);
        res.render('sports', { seasons: [], teams: [] });
    }
});


// Financial page (fetch and display financial data)
app.get('/financial', async (req, res) => {
    const financialData = await getFinancialData();
    res.render('financial', { financial: financialData });
});

// Visualization pages (Chart.js)
app.get('/visualize-sports', async (req, res) => {
    const sportsData = await getSportsData();
    res.render('visualize-sports', { sports: sportsData });
});

app.get('/visualize-financial', async (req, res) => {
    const financialData = await getFinancialData();
    res.render('visualize-financial', { financial: financialData });
});

// Routes
app.use('/', require('./routes/index.js'));
app.use('/users', require('./routes/users.js'));
app.use('/portfolio', portfolioRoutes);

const PORT = process.env.PORT || 3000;

app.listen(PORT, console.log(`Server running on  ${PORT}`));