module.exports = {
    MongoURI: 'mongodb+srv://dlcwtptfib:dlcwtptfib@cluster0.iubgh.mongodb.net/todo-app?retryWrites=true&w=majority&appName=Cluster0',
}