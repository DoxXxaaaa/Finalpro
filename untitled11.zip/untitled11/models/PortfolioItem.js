const mongoose = require('mongoose');

const PortfolioItemSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    images: [{
        type: String,
        required: true
    }],
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: {
        type: Date
    },
    deletedAt: {
        type: Date
    },
    userRole: {
        type: String,
        enum: ['admin', 'editor'],
        required: true
    }
});

const PortfolioItem = mongoose.model('PortfolioItem', PortfolioItemSchema);

module.exports = PortfolioItem;
