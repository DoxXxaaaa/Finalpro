const express = require('express');
const router = express.Router();
const PortfolioItem = require('../models/PortfolioItem');
const { ensureAuthenticated } = require('../config/auth');

// Get all portfolio items
router.get('/', async (req, res) => {
    try {
        const items = await PortfolioItem.find();
        res.render('portfolio', { items });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

// Create new portfolio item
router.get('/create', ensureAuthenticated, (req, res) => {
    if (req.user.userRole !== 'admin' && req.user.userRole !== 'editor') {
        return res.redirect('/dashboard');
    }
    res.render('createPortfolio');
});

router.post('/create', ensureAuthenticated, async (req, res) => {
    const { title, description, images } = req.body;
    const userRole = req.user.userRole;

    try {
        const newItem = new PortfolioItem({
            title,
            description,
            images: images.split(','), // Assuming images are passed as comma-separated URLs
            userRole
        });

        await newItem.save();
        res.redirect('/portfolio');
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

// Update portfolio item
router.get('/update/:id', ensureAuthenticated, async (req, res) => {
    try {
        const item = await PortfolioItem.findById(req.params.id);
        if (!item || (item.userRole !== req.user.userRole && req.user.userRole !== 'admin')) {
            return res.redirect('/portfolio');
        }
        res.render('updatePortfolio', { item });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

router.post('/update/:id', ensureAuthenticated, async (req, res) => {
    const { title, description, images } = req.body;

    try {
        const item = await PortfolioItem.findById(req.params.id);
        if (item && (item.userRole === req.user.userRole || req.user.userRole === 'admin')) {
            item.title = title;
            item.description = description;
            item.images = images.split(',');
            item.updatedAt = Date.now();
            await item.save();
            res.redirect('/portfolio');
        } else {
            res.status(403).send('Unauthorized');
        }
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

// Delete portfolio item
router.get('/delete/:id', ensureAuthenticated, async (req, res) => {
    try {
        const item = await PortfolioItem.findById(req.params.id);
        if (item && (item.userRole === req.user.userRole || req.user.userRole === 'admin')) {
            item.deletedAt = Date.now();
            await item.save();
            res.redirect('/portfolio');
        } else {
            res.status(403).send('Unauthorized');
        }
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

module.exports = router;
